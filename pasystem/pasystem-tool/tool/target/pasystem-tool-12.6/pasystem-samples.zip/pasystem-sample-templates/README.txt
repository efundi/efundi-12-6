This .zip file contains three different Popup alert templates: Image Wrap, Centered Image, and Two Column. 

To edit the desired template, open in the web development application of your choosing (or copy/paste the contents into a Sakai rich-text editor's "Source" view) and replace the placeholder content. 

When finished, save the modified html file and upload it back into the the PA System tool's Popup alert screen.
